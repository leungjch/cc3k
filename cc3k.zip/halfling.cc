#include "halfling.h"
#include "enemy.h"
#include <iostream>
#include <cmath>
using namespace std;

Halfling::Halfling() : Enemy{100, 15, 20, true, 'L', "Halfling"} {}

