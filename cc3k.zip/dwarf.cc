#include "dwarf.h"
#include "enemy.h"
#include <iostream>
#include <cmath>
using namespace std;

Dwarf::Dwarf() : Enemy{100, 20, 30, true, 'W', "Dwarf"} {}

