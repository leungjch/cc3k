#ifndef BOOSTATK_H
#define BOOSTATK_H
#include "potion.h"
#include <string>

class BoostAtk : public Potion {
    public:
    BoostAtk();
};

#endif
