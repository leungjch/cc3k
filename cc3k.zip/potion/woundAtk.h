#ifndef WOUNDATK_H
#define WOUNDATK_H
#include "potion.h"
#include <string>

class WoundAtk : public Potion {
    public:
    WoundAtk();
};

#endif
