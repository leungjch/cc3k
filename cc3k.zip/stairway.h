#ifndef STAIRWAY_H
#define STAIRWAY_H

#include "entity.h"

class Stairway : public Entity {
    public:

    Stairway();
    Stairway(int x, int y);

};
#endif
