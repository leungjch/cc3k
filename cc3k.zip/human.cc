#include "human.h"
#include "enemy.h"
#include <iostream>
#include <cmath>
using namespace std;

Human::Human() : Enemy{140, 20, 20, true, 'H', "Human"} {}
