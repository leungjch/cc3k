#ifndef RESTOREHEALTH_H
#define RESTOREHEALTH_H
#include "potion.h"
#include <string>

class RestoreHealth : public Potion {
    public:
    RestoreHealth();
};

#endif
