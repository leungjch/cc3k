#ifndef SMALLGOLD_H
#define SMALLGOLD_H

#include "gold.h"

class SmallPile : public Gold {
    public:
    SmallPile();
    static const int value = 1;
};
#endif
