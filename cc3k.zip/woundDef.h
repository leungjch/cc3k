#ifndef WOUNDDEF_H
#define WOUNDDEF_H
#include "potion.h"
#include <string>

class WoundDef : public Potion {
    public:
    WoundDef();
};

#endif
