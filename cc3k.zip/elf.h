#ifndef ELF_H
#define ELF_H
#include "enemy.h"
#include <memory>
class Elf : public Enemy {
    public:
    Elf();
};
#endif
