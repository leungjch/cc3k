#include "boostAtk.h"
#include "potion.h"

BoostAtk::BoostAtk() : Potion{
    "Potion of Boost Atk", 
    0, 
    5, 
    0, 
    false,
    "PC's gained Atk on this level."}
{}
