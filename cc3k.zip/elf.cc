#include "elf.h"
#include "enemy.h"
#include <iostream>
#include <cmath>
using namespace std;

Elf::Elf() : Enemy{140, 30, 10, true, 'E', "Elf"} {}

