#ifndef POISIONHEALTH_H
#define POISIONHEALTH_H
#include "potion.h"
#include <string>

class PoisonHealth : public Potion {
    public:
    PoisonHealth();
};

#endif
