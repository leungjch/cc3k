#include "boostDef.h"
#include "potion.h"

BoostDef::BoostDef() : Potion{
    "Potion of Boost Def", 
    0, 
    0, 
    5, 
    false,
    "PC gained Def on this level."}
{}
