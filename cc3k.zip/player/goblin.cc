#include "goblin.h"
#include "../character.h"
#include "player.h"

Goblin::Goblin() :  Player{110, 15, 20, "Goblin"} {}
