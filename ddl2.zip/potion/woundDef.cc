#include "woundDef.h"
#include "potion.h"

WoundDef::WoundDef() : Potion{
    "Potion of Wound Def", 
    0, 
    0, 
    -5, 
    false,
    "PC's Def decreased on this level."}
{}
