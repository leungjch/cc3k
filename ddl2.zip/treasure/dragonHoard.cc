#include "dragonHoard.h"
#include <memory>
using namespace std;

DragonHoard::DragonHoard() : Gold{"Dragon Hoard", 6, false} {}
