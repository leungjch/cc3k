#include "normalPile.h"
NormalPile::NormalPile() : Gold{"Medium Gold Pile", NormalPile::value} {}
