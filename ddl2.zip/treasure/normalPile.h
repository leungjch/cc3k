#ifndef MEDIUMGOLD_H
#define MEDIUMGOLD_H

#include "gold.h"

class NormalPile : public Gold {
    public:
    NormalPile();
    static const int value = 2;
};
#endif
