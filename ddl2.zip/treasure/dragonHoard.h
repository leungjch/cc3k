#ifndef DRAGONHOARD_H
#define DRAGONHOARD_H
#include <memory>
#include "gold.h"

class DragonHoard : public Gold {
    public:
    DragonHoard();
};
#endif
