#include "smallPile.h"
#include "gold.h"

SmallPile::SmallPile() : Gold{"Small Gold Pile", SmallPile::value} {}
