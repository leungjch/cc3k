#ifndef HALFLING_H
#define HALFLING_H
#include "enemy.h"
#include <memory>
class Halfling : public Enemy {
    public:
    Halfling();
};
#endif
