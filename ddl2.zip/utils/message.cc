#include "message.h"
#include <string>

Message::Message(std::string text, std::string color) : text{text}, color{color} {}
