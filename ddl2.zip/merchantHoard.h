#ifndef MERCHANTHOARD_H
#define MERCHANTHOARD_H

#include "gold.h"

class MerchantHoard : public Gold {
    public:
    MerchantHoard();
};
#endif
