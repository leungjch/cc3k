#include "restoreHealth.h"
#include "potion.h"

RestoreHealth::RestoreHealth() : Potion{
    "Potion of Restore Health", 
    10, 
    0, 
    0, 
    true,
    "PC gained HP."}
{}
