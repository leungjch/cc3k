#ifndef BOOSTDEF_H
#define BOOSTDEF_H
#include "potion.h"
#include <string>

class BoostDef : public Potion {
    public:
    BoostDef();
};

#endif
