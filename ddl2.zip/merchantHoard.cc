#include "merchantHoard.h"
MerchantHoard::MerchantHoard() : Gold{"Merchant Hoard", 4} {}
