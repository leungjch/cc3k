#include "shade.h"
#include "character.h"
#include "player.h"

Shade::Shade() :  Player{125, 25, 25, "Shade"} {}
