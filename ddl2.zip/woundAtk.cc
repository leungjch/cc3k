#include "woundAtk.h"
#include "potion.h"

WoundAtk::WoundAtk() : Potion{
    "Potion of Wound Atk", 
    0, 
    -5, 
    0, 
    false,
    "PC's Atk decreased on this level."}
{}
